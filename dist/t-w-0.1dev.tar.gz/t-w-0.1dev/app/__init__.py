#Import the necessary methods from tweepy library
from tweepy.streaming import StreamListener
from tweepy import OAuthHandler
from tweepy import Stream

access_token = "758586954539732992-oLPy6ZKtdFuFSdkvfxMdqkjjFFDx2RU"
access_token_secret = "BojAqDw4q1h8J4ZeGghlOoBgfcka3f5Wn10IX1eNB9sI2"
consumer_key = "GvkjcL1Z1KX9bFtWdflH0F4Hs"
consumer_secret = "0ArbTqJusB6MXW4TQvrDhfl6wYe180ABjSfA6XCF2P401mJ90f"